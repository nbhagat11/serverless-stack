import os
import boto3
import pymysql
import gzip
import io
import csv
import logging
from datetime import datetime

logger = logging.getLogger()
logger.setLevel(logging.INFO)

s3_client = boto3.client('s3')

def parse_datetime(dt_str):
    try:
        return datetime.strptime(dt_str[:19], '%Y-%m-%d %H:%M:%S')
    except Exception:
        return None

def parse_date(date_str):
    try:
        return datetime.strptime(date_str[:10], '%Y-%m-%d').date()
    except Exception:
        return None

def lambda_handler(event, context):
    try:
        # Read DB connection info from environment variables
        db_host = os.environ['DB_HOST']
        db_user = os.environ['DB_USER']
        db_password = os.environ['DB_PASSWORD']
        db_name = "opensky_dataset"
        table_name = "opensky_dataset_table3"

        # Connect to MySQL without specifying DB to create DB if needed
        conn = pymysql.connect(
            host=db_host,
            user=db_user,
            password=db_password,
            charset='utf8mb4',
            cursorclass=pymysql.cursors.DictCursor,
            autocommit=False
        )
        logger.info(f"Connected to MySQL at {db_host}")

        with conn.cursor() as cur:
            # Create database if not exists
            cur.execute(f"CREATE DATABASE IF NOT EXISTS {db_name}")
            logger.info(f"Database '{db_name}' ensured.")
        conn.select_db(db_name)

        with conn.cursor() as cur:
            # Create table if not exists with columns matching your CSV
            create_table_sql = f"""
            CREATE TABLE IF NOT EXISTS {table_name} (
                id INT AUTO_INCREMENT PRIMARY KEY,
                callsign VARCHAR(16),
                number VARCHAR(16),
                icao24 VARCHAR(16),
                registration VARCHAR(16),
                typecode VARCHAR(16),
                origin VARCHAR(16),
                destination VARCHAR(16),
                firstseen DATETIME,
                lastseen DATETIME,
                day DATE,
                latitude_1 DOUBLE,
                longitude_1 DOUBLE,
                altitude_1 DOUBLE,
                latitude_2 DOUBLE,
                longitude_2 DOUBLE,
                altitude_2 DOUBLE
            )
            """
            cur.execute(create_table_sql)
            conn.commit()
            logger.info(f"Table '{table_name}' ensured.")

        # Process each uploaded file in the event
        for record in event['Records']:
            bucket = record['s3']['bucket']['name']
            key = record['s3']['object']['key']
            logger.info(f"Processing file from bucket '{bucket}', key '{key}'")

            # Get gzipped file content from S3
            response = s3_client.get_object(Bucket=bucket, Key=key)
            gzip_body = response['Body'].read()

            # Decompress gzip in memory
            with gzip.GzipFile(fileobj=io.BytesIO(gzip_body), mode='rb') as gz:
                csv_bytes = gz.read()

            # Decode bytes to string (assuming UTF-8)
            csv_text = csv_bytes.decode('utf-8')

            # Parse CSV content
            csv_reader = csv.DictReader(io.StringIO(csv_text))

            with conn.cursor() as cur:
                row_count = 0
                for row in csv_reader:
                    data = (
                        row.get('callsign'),
                        row.get('number'),
                        row.get('icao24'),
                        row.get('registration'),
                        row.get('typecode'),
                        row.get('origin'),
                        row.get('destination'),
                        parse_datetime(row.get('firstseen', '')),
                        parse_datetime(row.get('lastseen', '')),
                        parse_date(row.get('day', '')),
                        float(row['latitude_1']) if row.get('latitude_1') else None,
                        float(row['longitude_1']) if row.get('longitude_1') else None,
                        float(row['altitude_1']) if row.get('altitude_1') else None,
                        float(row['latitude_2']) if row.get('latitude_2') else None,
                        float(row['longitude_2']) if row.get('longitude_2') else None,
                        float(row['altitude_2']) if row.get('altitude_2') else None,
                    )
                    insert_sql = f"""
                    INSERT INTO {table_name} 
                    (callsign, number, icao24, registration, typecode, origin, destination, firstseen, lastseen, day,
                     latitude_1, longitude_1, altitude_1, latitude_2, longitude_2, altitude_2)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                    """
                    cur.execute(insert_sql, data)
                    row_count += 1

                conn.commit()
                logger.info(f"Inserted {row_count} rows into '{table_name}'.")

        conn.close()

        return {
            'statusCode': 200,
            'body': f"Successfully ingested {row_count} rows into '{db_name}.{table_name}'."
        }

    except Exception as e:
        logger.error(f"Error during processing: {e}", exc_info=True)
        return {
            'statusCode': 500,
            'body': f"Error: {str(e)}"
        }

