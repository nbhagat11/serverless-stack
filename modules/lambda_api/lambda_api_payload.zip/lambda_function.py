import json
import pymysql
import os
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    try:
        connection = pymysql.connect(
            host=os.environ['DB_HOST'],
            user=os.environ['DB_USER'],
            password=os.environ['DB_PASSWORD'],
            database=os.environ['DB_NAME'],
            charset='utf8mb4',
            cursorclass=pymysql.cursors.DictCursor,
            autocommit=True
        )

        with connection.cursor() as cursor:
            # 1. Total row count
            cursor.execute("SELECT COUNT(*) AS row_count FROM opensky_dataset_table2")
            row_count = cursor.fetchone()['row_count']

            # 2. Last transponder seen time
            cursor.execute("SELECT MAX(lastseen) AS last_seen FROM opensky_dataset_table2")
            last_seen = cursor.fetchone()['last_seen']

            # 3. Most popular destination
            cursor.execute("""
                SELECT destination, COUNT(*) AS cnt
                FROM opensky_dataset_table2
                GROUP BY destination
                ORDER BY cnt DESC
                LIMIT 1
            """)
            most_popular_destination = cursor.fetchone()['destination']

            # 4. Unique transponders
            cursor.execute("SELECT COUNT(DISTINCT icao24) AS unique_icao24 FROM opensky_dataset_table2")
            unique_transponders = cursor.fetchone()['unique_icao24']

        connection.close()

        return {
            "statusCode": 200,
            "body": json.dumps({
                "row_count": row_count,
                "last_transponder_seen_at": str(last_seen),
                "most_popular_destination": most_popular_destination,
                "count_of_unique_transponders": unique_transponders
            })
        }

    except Exception as e:
        logger.error(f"Error while querying metrics: {e}")
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)})
        }

